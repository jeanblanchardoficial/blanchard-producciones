# Blanchard Producciones — Event Management AI

Aplicación web responsive/PWA para planificar y producir eventos de principio a fin. Funciona en PC y celular desde el navegador y puede instalarse como PWA.

## Incluye
- Cuentas de usuario y sesión.
- Proyectos/eventos y plantillas por tipo.
- Plan maestro con 19 áreas de producción.
- Checklist, responsables y fechas.
- Cronograma y cuenta de avance.
- Mapa mental inicial + generación detallada mediante IA.
- Finanzas básicas: presupuesto, ingresos, costos, resultado y contingencia.
- Equipo y roles.
- Módulos de logística, marketing, producción técnica y documentos.
- Centro de Control IA para auditorías, riesgos, cronogramas y optimización.
- Actualizaciones en tiempo real con Socket.IO.
- Notificaciones internas.
- Persistencia local en `data.json` (para un despliegue real se recomienda migrar a PostgreSQL/Supabase).
- PWA para instalar en Android/iOS/PC.

## Ejecutar
Requiere Node.js 20+.

```bash
npm install
```

Crea `.env` a partir de `.env.example` y configura:

```env
OPENAI_API_KEY=tu_clave_privada
OPENAI_MODEL=gpt-5-mini
JWT_SECRET=una_cadena_larga_y_aleatoria
PORT=3000
```

Luego:

```bash
npm start
```

Abre `http://localhost:3000`.

## Despliegue recomendado
Usa un servicio que soporte Node.js/Docker y almacenamiento persistente para `data.json` (o sustituye el almacenamiento por PostgreSQL). Define las variables de entorno en el panel del proveedor; **no subas `.env` al repositorio**.

## Próxima capa recomendada para producción comercial
1. PostgreSQL/Supabase para datos multiusuario.
2. Control de acceso por organización/proyecto/área.
3. Invitaciones por email.
4. Notificaciones push y email.
5. Archivos en almacenamiento S3-compatible.
6. Auditoría de cambios.
7. Calendario con dependencias tipo Gantt.
8. Presupuestos por partidas y proveedores.
9. CRM de artistas, clientes y proveedores.
10. Entradas/inscripciones y pagos.
11. Generación de contratos, riders, órdenes de compra y documentos PDF.
12. Mapas/planos interactivos del recinto.
13. Aplicación móvil nativa Android/iOS si se requiere publicación en tiendas.
