import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import OpenAI from 'openai';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(), server=http.createServer(app), io=new Server(server);
app.use(express.json({limit:'5mb'})); app.use(express.static(path.join(__dirname,'public')));
const DB=process.env.DB_PATH||path.join(__dirname,'data.json');
const dbDir=path.dirname(DB);
fs.mkdirSync(dbDir,{recursive:true});
const readDB=()=>{try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {users:[],projects:[],notifications:[]}}};
const writeDB=d=>{fs.mkdirSync(dbDir,{recursive:true});fs.writeFileSync(DB,JSON.stringify(d,null,2));};
const hash=password=>crypto.pbkdf2Sync(String(password),process.env.PASSWORD_SALT||SECRET,120000,32,'sha256').toString('hex');
const SECRET=process.env.JWT_SECRET||crypto.createHash('sha256').update('blanchard-development-secret').digest('hex');
const b64=s=>Buffer.from(s).toString('base64url');
const makeToken=u=>b64(JSON.stringify({id:u.id,email:u.email,name:u.name,role:u.role,exp:Date.now()+7*864e5}))+'.'+crypto.createHmac('sha256',SECRET).update(u.id).digest('base64url');
function auth(req,res,next){const raw=(req.headers.authorization||'').replace('Bearer ','');try{const [a,sig]=raw.split('.'),u=JSON.parse(Buffer.from(a,'base64url').toString());const expected=crypto.createHmac('sha256',SECRET).update(u.id).digest('base64url');if(sig!==expected||u.exp<Date.now())throw 0;req.user=u;next()}catch{return res.status(401).json({error:'Sesión no válida'})}}
function notify(projectId,title,message,type='info'){const d=readDB();const n={id:crypto.randomUUID(),projectId,type,title,message,read:false,created_at:new Date().toISOString()};d.notifications.unshift(n);d.notifications=d.notifications.slice(0,500);writeDB(d);io.emit('notification:new',n)}
function projectRow(id){return readDB().projects.find(p=>p.id===id)||null}
function saveProject(p){const d=readDB();const now=new Date().toISOString();p={...p,updatedAt:now};const i=d.projects.findIndex(x=>x.id===p.id);if(i<0)d.projects.unshift(p);else d.projects[i]=p;writeDB(d);return p}
app.post('/api/auth/register',(req,res)=>{const {email,name,password}=req.body;if(!email||!name||!password||password.length<6)return res.status(400).json({error:'Nombre, email y contraseña (mín. 6) son requeridos'});try{const normalized=(email||'').trim().toLowerCase();const d=readDB();if(d.users.some(x=>x.email===normalized))return res.status(409).json({error:'El email ya está registrado'});const u={id:crypto.randomUUID(),email:normalized,name:name.trim(),role:'admin',password_hash:hash(password),created_at:new Date().toISOString()};d.users.push(u);writeDB(d);res.json({token:makeToken(u),user:{id:u.id,email:u.email,name:u.name,role:u.role}})}catch(e){res.status(409).json({error:'El email ya está registrado'})}});
app.post('/api/auth/login',(req,res)=>{const {email,password}=req.body;const u=readDB().users.find(x=>x.email===(email||'').toLowerCase());if(!u||u.password_hash!==hash(password||''))return res.status(401).json({error:'Credenciales incorrectas'});res.json({token:makeToken(u),user:{id:u.id,email:u.email,name:u.name,role:u.role}})});
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.get('/api/projects',auth,(req,res)=>res.json(readDB().projects));
app.post('/api/projects',auth,(req,res)=>{const p={id:crypto.randomUUID(),ownerId:req.user.id,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),...req.body};saveProject(p);io.emit('project:changed',p);notify(p.id,'Nuevo evento creado',`${p.name} fue creado por ${req.user.name}`);res.json(p)});
app.put('/api/projects/:id',auth,(req,res)=>{const p=projectRow(req.params.id);if(!p)return res.status(404).json({error:'Proyecto no encontrado'});const next=saveProject({...p,...req.body});io.emit('project:changed',next);notify(next.id,'Proyecto actualizado',`${req.user.name} modificó ${next.name}`);res.json(next)});
app.delete('/api/projects/:id',auth,(req,res)=>{const d=readDB();d.projects=d.projects.filter(p=>p.id!==req.params.id);writeDB(d);io.emit('project:deleted',req.params.id);res.status(204).end()});
app.get('/api/notifications',auth,(req,res)=>res.json(readDB().notifications.slice(0,100)));
app.post('/api/notifications/:id/read',auth,(req,res)=>{const d=readDB();const n=d.notifications.find(x=>x.id===req.params.id);if(n)n.read=true;writeDB(d);res.json({ok:true})});
app.post('/api/ai',auth,async(req,res)=>{if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Configura OPENAI_API_KEY en el servidor.'});try{const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});const r=await client.responses.create({model:process.env.OPENAI_MODEL||'gpt-5-mini',instructions:'Eres Director de Producción IA de Blanchard Producciones. Responde en español. Analiza eventos artísticos, holísticos, corporativos, sociales, festivales, congresos y otros. Sé práctico, detecta dependencias, riesgos, costos y tareas. No inventes datos críticos; usa supuestos claramente marcados. Si entregas cronogramas, usa fases y fechas relativas a la fecha del evento.',input:req.body.prompt});res.json({text:r.output_text})}catch(e){res.status(500).json({error:'Error de IA: '+e.message})}});
io.on('connection',s=>s.emit('projects:all',readDB().projects));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
server.listen(process.env.PORT||3000,()=>console.log(`Blanchard Producciones en puerto ${process.env.PORT||3000}`));
